<template>
  <div>Month component</div>
</template>

<script>
    export default {
        name: "Month"
    }
</script>

<style scoped>

</style>
